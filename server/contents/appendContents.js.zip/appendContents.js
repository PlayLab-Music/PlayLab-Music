function appendContents(){
    console.log("myScript")
    console.log(Date.now())
    var players = [];
    if(onYouTubeIframeAPIReady){
        window.YT.ready(function(){
            $("#glider").children().remove();
            console.log("youtube contents")
            console.log(Date.now())
            for(var i=0; i<9; i++){
                var div_id = '<div class="content-box-wrapper" id="'+i+'"></div>'
                var div_tag = $(div_id)
                div_tag.appendTo($(".glider"))
                //window.gliders.addItem(div_tag.get(0))
                var pl = createContentBox($(div_tag), i);
                players.push(pl)
                if (i ==0){
                    var hide_id = "#"+i
                    $(hide_id).hide()
                }
                console.log(i)
            }
        });
    }         
};

function secondSearch(){
    var players = [];
    if(onYouTubeIframeAPIReady){
        window.YT.ready(function(){
            console.log("youtube contents")
            console.log(Date.now())
            $("#glider").children().remove();
            for(var i=0; i<9; i++){

                var div_id = '<div class="content-box-wrapper" id="'+i+'"></div>'
                var div_tag = $(div_id)
                //div_tag.appendTo($(".glider"))
                var pl = createContentBox($(div_tag), i);
                players.push(pl)
                if (i ==0){
                    var hide_id = "#"+i
                    $(hide_id).hide()
                }
                id_no = "#" + i
                //window.gliders.addItem($(id_no).get(0))
                console.log(i)
            }
        });
    }         
}

function createGlider(){
    var currentSlide;
    document.querySelector('#glider').addEventListener('glider-slide-visible', function(event){
        var glider = Glider(this);
        if (currentSlide){
            currentSlide.css('transform', 'scale(1.0)')
        }

        currentSlide = $(".glider-slide.center")
        console.log('Slide Visible %s', event.detail.slide);
        
    });
    document.querySelector('#glider').addEventListener('glider-slide-hidden', function(event){
        console.log('Slide Hidden %s', event.detail.slide)
    });
    document.querySelector('#glider').addEventListener('glider-refresh', function(event){
        console.log('Refresh')
    });
    document.querySelector('#glider').addEventListener('glider-loaded', function(event){
        console.log('Loaded')
    });

    var gliders;
    window.gliders = new Glider(document.querySelector('#glider'), {
        slidesToShow: 'auto',
        slidesToScroll: 1,
        itemWidth: 150,
        draggable: true,
        scrollLock: false,
        rewind: true,
        responsive: [
            {
                breakpoint: 800,
                settings: {
                    slidesToScroll: 'auto',
                    itemWidth: 300,
                    slidesToShow: 5,
                    exactWidth: true
                }
            },
            {
                breakpoint: 700,
                settings: {
                    slidesToScroll: 4,
                    slidesToShow: 4,
                    dots: false,
                    arrows: false,
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToScroll: 3,
                    slidesToShow: 3
                }
            },
            {
                breakpoint: 500,
                settings: {
                    slidesToScroll: 2,
                    slidesToShow: 2,
                    dots: false,
                    arrows: false,
                    scrollLock: true
                }
            }
        ]
    });
    console.log("created")
    $(".glider-track").remove()
    };